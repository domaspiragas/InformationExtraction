public final class patterns {
    public static final String[] 
    		pattern_Victim_after= {"assasssination of", "shooting of","death of","bombing of","attack on","assassination on","bombard on"
    				,"kidnapping of","murder of","death of ","murdered", "the murder","the murdered","attack against","the attacked"
    				,"the assassinated","the bombarded","bombarding of","abduction of","arson of"},
    		pattern_Victim_before= {"murdered","were bombarded","were kidnapped","were murdered","were attacked","were assassinated",
    				"were killed","were abducted","was dead","were dead"},
    		pattern_Ind_after= {"were murdered by","were kidnapped by","were attacked by","were arson by","were burned by",
    				"were kidnapped by","were targeted by","were abducted by","was murdered by","was kidnapped by","was attacked by"
    				,"was arson by","was burned by","was kidnapped by","was targeted by","was abducted by","commition points to"
    				,"was planned by","was approved by","who shot","blamed on","was ambushed by"},
    		pattern_Ind_before={"participated in crime","implicated in the murder","implicated in the burining of",
    				"implicated in the attacking of","implicated in the assassination of","implicated in the kidnapping of",
    				"implicated in the bombing of","implicated in the exploding of","participated in killing of",
    				"participated in murder of","participated in murdering of ","participated in kidnapping of ",
    				"participated in the kidnap of","participated in abducting of","participated in abduct of",
    				"participated in bombing of","participated in arsoning","participated in burning","participated in robbing",
    				"participated in burnning","participated in attcking of","participated in murder of"
    				,"participated in murdering of","participated in assassination of","participated in assassinating",
    				"participated in death of","was involved in charge of","implicated in the shooting of"
    				,"implicated in the robbery","implicated in the robbing of","participated in robbery"
    				,"hurled dynamite","hurled bomb","hurled TNT","threw dynamite","threw TNT","threw bomb","conducted attack"
    				,"conducted bombing","committed attack","conducted murder","committed murder","was involved in murder of"
    				,"was involved in killing of","was involved in bombing of","was involved in  of","were involved in murder of"
    				,"were involved in killing of","were involved in bombing of","were involved in charge of","attacked","burnt"
    				,"claimed responsibility","is being held responsibility","are being held responsibility","was the prepetrator"
    				,"done attack against","were arrested","was arrested","threw explosive ","hurled explosive","who shot"
    				,"fired at","blamed","were involved in the murder","perpetrated it","conducted"},
    		pattern_target_after= {"bombs on","kidnap of","rob of","robbery of","kidnapping of","kidnap of","attack on","exploded in"
    				,"damaged","threw explosive at","hurled explosive at","hurled dynamite at","threw dynamite at",
    				"hurled bomb at","threw bomb at","destroyed"},
    		pattern_target_before= {"were destroyed","was destroyed","was damaged","was destroyed","wewre drailed","was drailed"
    				,"was set ablaze","was set on fire"},
    		pattern_org_before= {"did it"},
    		pattern_org_middle= {"were murdered by _ members"},
    		pattern_org_after= {"members of the band","members of"};
    }
